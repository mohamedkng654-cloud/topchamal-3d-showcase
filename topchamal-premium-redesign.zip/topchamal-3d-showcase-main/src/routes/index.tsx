import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Heart,
  Menu,
  Minus,
  PackageCheck,
  Plus,
  Search,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Truck,
  UserRound,
  WalletCards,
  X,
  MessageCircle,
} from "lucide-react";
import catalog from "../data/products.json";
import { categories } from "../data/categories";
import brandLogo from "../assets/brand/topchamal-logo.png.asset.json";

type Product = (typeof catalog.products)[number];
type CartLine = { id: string; quantity: number };

const products = catalog.products as Product[];
const formatPrice = (n: number) =>
  new Intl.NumberFormat("fr-MA", { maximumFractionDigits: 2 }).format(n);
const categoryName = (id: string) => categories.find((c) => c.id === id)?.label || "أجهزة منزلية";
const META =
  "اكتشف أجهزة منزلية مختارة بعناية من Topchamal، مع توصيل في المغرب والدفع عند الاستلام.";
const whatsappUrl = (text: string) =>
  `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Topchamal | أجهزة منزلية بجودة تستحقها" },
      { name: "description", content: META },
      { property: "og:title", content: "Topchamal | أجهزة منزلية بجودة تستحقها" },
      { property: "og:description", content: META },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Storefront,
});

function Price({ product, large = false }: { product: Product; large?: boolean }) {
  return (
    <div className={large ? "price price-large" : "price"}>
      <strong className="num">{formatPrice(product.price)}</strong>
      <span>د.م</span>
      {product.oldPrice ? <del className="num">{formatPrice(product.oldPrice)} د.م</del> : null}
    </div>
  );
}

export function Storefront() {
  const [active, setActive] = useState("all");
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<CartLine[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [drawer, setDrawer] = useState(false);
  const [checkout, setCheckout] = useState(false);
  const [menu, setMenu] = useState(false);
  const [selected, setSelected] = useState<Product | null>(null);
  const [orderSent, setOrderSent] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("topchamal-cart") || "[]");
      if (Array.isArray(saved))
        setCart(
          saved.filter((v: CartLine) => v?.id && Number.isInteger(v.quantity) && v.quantity > 0),
        );
      const savedWishlist = JSON.parse(localStorage.getItem("topchamal-wishlist") || "[]");
      if (Array.isArray(savedWishlist))
        setWishlist(savedWishlist.filter((v) => typeof v === "string"));
    } catch {
      // Ignore malformed local storage and start fresh.
    }
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (loaded) localStorage.setItem("topchamal-cart", JSON.stringify(cart));
  }, [cart, loaded]);
  useEffect(() => {
    if (loaded) localStorage.setItem("topchamal-wishlist", JSON.stringify(wishlist));
  }, [wishlist, loaded]);

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    return products.filter((product) => {
      const categoryMatch = active === "all" || product.category === active;
      const searchMatch =
        !query ||
        product.name.toLowerCase().includes(query) ||
        categoryName(product.category).includes(query);
      return categoryMatch && searchMatch;
    });
  }, [active, search]);
  const featured = products.filter((p) => p.oldPrice).slice(0, 4);
  const [featuredIndex, setFeaturedIndex] = useState(0);
  const featuredProduct = featured[featuredIndex % featured.length] || products[0];
  const count = cart.reduce((sum, line) => sum + line.quantity, 0);
  const total = cart.reduce(
    (sum, line) => sum + (products.find((p) => p.id === line.id)?.price || 0) * line.quantity,
    0,
  );

  function add(product: Product) {
    setCart((current) => {
      const existing = current.find((line) => line.id === product.id);
      return existing
        ? current.map((line) =>
            line.id === product.id ? { ...line, quantity: line.quantity + 1 } : line,
          )
        : [...current, { id: product.id, quantity: 1 }];
    });
    setDrawer(true);
    setCheckout(false);
  }
  function qty(id: string, delta: number) {
    setCart((current) =>
      current
        .map((line) => (line.id === id ? { ...line, quantity: line.quantity + delta } : line))
        .filter((line) => line.quantity > 0),
    );
  }
  function toggleWishlist(id: string) {
    setWishlist((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  }
  function chooseCategory(id: string) {
    setActive(id);
    document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
  }
  function order(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = String(data.get("name") || "").trim();
    const phone = String(data.get("phone") || "").trim();
    const city = String(data.get("city") || "").trim();
    if (!name || !/^0[567]\d{8}$|^\+?212[567]\d{8}$/.test(phone) || !city) return;
    const lines = cart
      .map((line) => {
        const product = products.find((p) => p.id === line.id);
        return product
          ? `• ${product.name} × ${line.quantity} — ${formatPrice(product.price * line.quantity)} د.م`
          : "";
      })
      .filter(Boolean);
    const text = `طلب جديد من Topchamal\n\n${lines.join("\n")}\n\nالمجموع: ${formatPrice(total)} د.م\nالاسم: ${name}\nالهاتف: ${phone}\nالمدينة: ${city}\nطريقة الدفع: عند الاستلام`;
    window.open(whatsappUrl(text), "_blank", "noopener,noreferrer");
    setOrderSent(true);
  }

  return (
    <main dir="rtl">
      <div className="announcement">
        <div className="wrap announcement-inner">
          <span>
            <Truck size={15} /> التوصيل متاح لجميع أنحاء المغرب
          </span>
          <span className="announcement-desktop">الدفع عند الاستلام · دعم سريع عبر واتساب</span>
          <a href="#faq">
            اكتشف المزيد <ArrowLeft size={14} />
          </a>
        </div>
      </div>
      <header className="site-header">
        <div className="wrap header-main">
          <button
            className="icon-button mobile-only"
            aria-label="فتح القائمة"
            onClick={() => setMenu((value) => !value)}
          >
            <Menu size={21} />
          </button>
          <a href="#home" className="brand" aria-label="Topchamal">
            <img src={brandLogo.url} alt="Topchamal" width="104" height="58" />
          </a>
          <nav className="desktop-nav" aria-label="القائمة الرئيسية">
            <a href="#home">الرئيسية</a>
            <a href="#categories">التصنيفات</a>
            <a href="#products">المنتجات</a>
            <a href="#about">لماذا Topchamal</a>
          </nav>
          <div className="header-tools">
            <label className="header-search">
              <Search size={18} />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="ابحث عن منتج..."
                aria-label="ابحث عن منتج"
              />
              <kbd>/</kbd>
            </label>
            <button className="icon-button account-button" aria-label="الحساب">
              <UserRound size={20} />
            </button>
            <button
              className="icon-button cart-button"
              aria-label="فتح السلة"
              onClick={() => setDrawer(true)}
            >
              <ShoppingBag size={20} />
              {count > 0 && <span className="cart-count num">{count}</span>}
            </button>
          </div>
        </div>
        {menu && (
          <nav className="mobile-nav">
            <a href="#home" onClick={() => setMenu(false)}>
              الرئيسية
            </a>
            <a href="#categories" onClick={() => setMenu(false)}>
              التصنيفات
            </a>
            <a href="#products" onClick={() => setMenu(false)}>
              المنتجات
            </a>
            <a href="#about" onClick={() => setMenu(false)}>
              لماذا Topchamal
            </a>
            <a href="#faq" onClick={() => setMenu(false)}>
              الأسئلة الشائعة
            </a>
          </nav>
        )}
      </header>

      <section className="hero" id="home">
        <div className="wrap hero-grid">
          <div className="hero-copy">
            <span className="eyebrow">
              <Sparkles size={15} /> مختارات Topchamal
            </span>
            <h1>
              لبيتٍ أجمل،
              <br />
              <em>اختيارات أذكى.</em>
            </h1>
            <p>
              أجهزة منزلية تجمع بين الأداء والتصميم، مختارة بعناية لترافق تفاصيل يومك في المطبخ
              والبيت.
            </p>
            <div className="hero-actions">
              <button
                className="primary-button"
                onClick={() =>
                  document.getElementById("products")?.scrollIntoView({ behavior: "smooth" })
                }
              >
                تسوق الآن <ArrowLeft size={17} />
              </button>
              <button
                className="text-button"
                onClick={() =>
                  document.getElementById("categories")?.scrollIntoView({ behavior: "smooth" })
                }
              >
                اكتشف التصنيفات <ChevronLeft size={17} />
              </button>
            </div>
            <div className="hero-note">
              <ShieldCheck size={18} />
              <span>
                <strong>اختيار موثوق</strong>
                <small>منتجات حقيقية وأسعار بالدرهم المغربي</small>
              </span>
            </div>
          </div>
          <div className="hero-product">
            <div className="hero-orbit orbit-one" />
            <div className="hero-orbit orbit-two" />
            <div className="hero-image-card">
              <span className="floating-label">اختيار اليوم</span>
              <img
                src={products[0]?.image}
                alt={products[0]?.name || "منتج Topchamal"}
                fetchPriority="high"
              />
            </div>
            <div className="hero-stamp">
              <span className="num">100%</span>
              <small>لبيتك</small>
            </div>
          </div>
        </div>
      </section>

      <section className="benefits">
        <div className="wrap benefits-grid">
          <div>
            <Truck size={22} />
            <span>
              <strong>توصيل في المغرب</strong>
              <small>إلى مدينتك أينما كنت</small>
            </span>
          </div>
          <div>
            <WalletCards size={22} />
            <span>
              <strong>الدفع عند الاستلام</strong>
              <small>اطلب بثقة وراحة</small>
            </span>
          </div>
          <div>
            <PackageCheck size={22} />
            <span>
              <strong>تشكيلة مختارة</strong>
              <small>حلول عملية لكل بيت</small>
            </span>
          </div>
          <div>
            <MessageCircle size={22} />
            <span>
              <strong>نحن هنا لمساعدتك</strong>
              <small>تواصل معنا عبر واتساب</small>
            </span>
          </div>
        </div>
      </section>

      <section className="section" id="categories">
        <div className="wrap">
          <div className="section-heading-row">
            <div>
              <span className="eyebrow plain">تسوق حسب احتياجك</span>
              <h2>كل ما يجعل يومك أسهل</h2>
            </div>
            <p>
              اكتشف فئات مختارة بعناية
              <br />
              للمطبخ والبيت العصري.
            </p>
          </div>
          <div className="category-grid">
            {categories.map((category) => {
              const image =
                catalog.categoryImages[category.id as keyof typeof catalog.categoryImages] ||
                products.find((product) => product.category === category.id)?.image;
              const categoryCount = products.filter(
                (product) => product.category === category.id,
              ).length;
              return (
                <button
                  key={category.id}
                  className={`category-card ${active === category.id ? "active" : ""}`}
                  onClick={() => chooseCategory(category.id)}
                >
                  <div className="category-image">
                    {image ? (
                      <img src={image} loading="lazy" alt={category.label} />
                    ) : (
                      <span>✦</span>
                    )}
                  </div>
                  <div>
                    <strong>{category.label}</strong>
                    <small>{categoryCount ? `${categoryCount} منتجات` : "اكتشف المجموعة"}</small>
                  </div>
                  <ChevronLeft size={17} />
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {featuredProduct && (
        <section className="featured-band">
          <div className="wrap featured-grid">
            <div className="featured-copy">
              <span className="eyebrow plain">عرض حقيقي من التشكيلة</span>
              <h2>
                اختيار يستحق
                <br />
                <em>مكاناً في بيتك.</em>
              </h2>
              <p>{featuredProduct.description}</p>
              <h3>{featuredProduct.name}</h3>
              <Price product={featuredProduct} large />
              <div className="featured-actions">
                <button className="primary-button" onClick={() => add(featuredProduct)}>
                  أضف إلى السلة <ShoppingBag size={17} />
                </button>
                <button
                  className="round-button"
                  aria-label="المنتج السابق"
                  onClick={() =>
                    setFeaturedIndex((value) => (value - 1 + featured.length) % featured.length)
                  }
                >
                  <ChevronRight size={18} />
                </button>
                <button
                  className="round-button"
                  aria-label="المنتج التالي"
                  onClick={() => setFeaturedIndex((value) => (value + 1) % featured.length)}
                >
                  <ChevronLeft size={18} />
                </button>
              </div>
            </div>
            <div className="featured-image">
              <span className="sale-badge">سعر سابق حقيقي</span>
              <img src={featuredProduct.image} loading="lazy" alt={featuredProduct.name} />
            </div>
          </div>
        </section>
      )}

      <section className="section products-section" id="products">
        <div className="wrap">
          <div className="section-heading-row">
            <div>
              <span className="eyebrow plain">اختيارات Topchamal</span>
              <h2>منتجات مميزة</h2>
            </div>
            <p>
              أسعار واضحة بالدرهم المغربي،
              <br />
              وتفاصيل تساعدك على الاختيار.
            </p>
          </div>
          <div className="product-toolbar">
            <div className="filter-row">
              <button className={active === "all" ? "active" : ""} onClick={() => setActive("all")}>
                الكل
              </button>
              {categories
                .filter((category) => products.some((product) => product.category === category.id))
                .map((category) => (
                  <button
                    key={category.id}
                    className={active === category.id ? "active" : ""}
                    onClick={() => setActive(category.id)}
                  >
                    {category.label}
                  </button>
                ))}
            </div>
            <span className="result-count">{filtered.length} منتجات</span>
          </div>
          {filtered.length ? (
            <div className="product-grid">
              {filtered.map((product) => (
                <article className="product-card" key={product.id}>
                  <div className="product-photo" onClick={() => setSelected(product)}>
                    <button
                      className={`wishlist-button ${wishlist.includes(product.id) ? "liked" : ""}`}
                      aria-label="إضافة إلى المفضلة"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleWishlist(product.id);
                      }}
                    >
                      <Heart
                        size={18}
                        fill={wishlist.includes(product.id) ? "currentColor" : "none"}
                      />
                    </button>
                    {product.oldPrice ? <span className="sale-chip">عرض</span> : null}
                    <img src={product.image} loading="lazy" alt={product.name} />
                  </div>
                  <div className="product-info">
                    <span className="product-category">{categoryName(product.category)}</span>
                    <h3 onClick={() => setSelected(product)}>{product.name}</h3>
                    <div className="product-footer">
                      <Price product={product} />
                      <button
                        className="add-product"
                        aria-label={`أضف ${product.name} إلى السلة`}
                        onClick={() => add(product)}
                      >
                        <Plus size={19} />
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <Search size={26} />
              <p>لم نعثر على منتجات مطابقة لبحثك.</p>
              <button
                className="text-button"
                onClick={() => {
                  setSearch("");
                  setActive("all");
                }}
              >
                عرض كل المنتجات
              </button>
            </div>
          )}
        </div>
      </section>

      <section className="about-section" id="about">
        <div className="wrap about-grid">
          <div>
            <span className="eyebrow plain">تجربة تسوق أبسط</span>
            <h2>
              أنت تختار.
              <br />
              <em>نحن نسهل الباقي.</em>
            </h2>
          </div>
          <div className="about-points">
            <div>
              <span>01</span>
              <div>
                <strong>منتجات عملية</strong>
                <p>تشكيلة من الأجهزة التي تحتاجها فعلاً في تفاصيل يومك.</p>
              </div>
            </div>
            <div>
              <span>02</span>
              <div>
                <strong>طلب مباشر</strong>
                <p>أضف إلى السلة وأرسل طلبك بسهولة عبر واتساب.</p>
              </div>
            </div>
            <div>
              <span>03</span>
              <div>
                <strong>وضوح من البداية</strong>
                <p>أسعار بالدرهم المغربي ومعلومات واضحة قبل تأكيد الطلب.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section faq-section" id="faq">
        <div className="wrap faq-layout">
          <div>
            <span className="eyebrow plain">نحن هنا لمساعدتك</span>
            <h2>أسئلة تتكرر</h2>
            <p>
              هل لديك سؤال آخر؟{" "}
              <a
                href={whatsappUrl("مرحباً، أريد الاستفسار عن منتجات Topchamal")}
                target="_blank"
                rel="noreferrer"
              >
                تواصل معنا عبر واتساب
              </a>
            </p>
          </div>
          <div className="faq-list">
            <details>
              <summary>
                كيف أرسل طلبي؟ <Plus size={18} />
              </summary>
              <p>
                أضف المنتجات إلى السلة، أدخل اسمك ورقم هاتفك ومدينتك، ثم شارك رسالة الطلب الجاهزة
                عبر واتساب.
              </p>
            </details>
            <details>
              <summary>
                هل الأسعار بالدرهم المغربي؟ <Plus size={18} />
              </summary>
              <p>نعم، جميع الأسعار المعروضة بالدرهم المغربي (د.م).</p>
            </details>
            <details>
              <summary>
                هل يمكن الدفع عند الاستلام؟ <Plus size={18} />
              </summary>
              <p>
                نعم، نموذج الطلب يدعم الدفع عند الاستلام. يرجى تأكيد تفاصيل التوصيل مع المتجر عبر
                واتساب.
              </p>
            </details>
          </div>
        </div>
      </section>

      <footer className="footer">
        <div className="wrap">
          <div className="footer-grid">
            <div>
              <a href="#home" className="footer-brand">
                <img src={brandLogo.url} alt="Topchamal" width="104" height="58" />
              </a>
              <p>أجهزة منزلية مختارة بعناية، لتجعل كل لحظة في بيتك أسهل وأجمل.</p>
              <a
                className="footer-whatsapp"
                href={whatsappUrl("مرحباً، أريد الاستفسار عن منتجات Topchamal")}
                target="_blank"
                rel="noreferrer"
              >
                <MessageCircle size={16} /> تواصل عبر واتساب
              </a>
            </div>
            <div>
              <h4>تسوق</h4>
              <a href="#categories">التصنيفات</a>
              <a href="#products">كل المنتجات</a>
              <a href="#featured">اختيار اليوم</a>
            </div>
            <div>
              <h4>المساعدة</h4>
              <a href="#faq">الأسئلة الشائعة</a>
              <a href="#about">التوصيل والدفع</a>
              <a href="https://topchamal.ma/pages/contact-us" target="_blank" rel="noreferrer">
                تواصل معنا
              </a>
            </div>
            <div>
              <h4>معلومات</h4>
              <a href="https://topchamal.ma/pages/return-policy" target="_blank" rel="noreferrer">
                الاستبدال والاسترجاع
              </a>
              <a href="https://topchamal.ma/pages/privacy-policy" target="_blank" rel="noreferrer">
                سياسة الخصوصية
              </a>
              <a
                href="https://topchamal.ma/pages/terms-and-conditions"
                target="_blank"
                rel="noreferrer"
              >
                الشروط والأحكام
              </a>
            </div>
          </div>
          <div className="footer-bottom">
            <span>© 2026 Topchamal. جميع الحقوق محفوظة.</span>
            <span>صنع لبيتك في المغرب</span>
          </div>
        </div>
      </footer>

      <a
        className="whatsapp-float"
        href={whatsappUrl("مرحباً، أريد الاستفسار عن منتجات Topchamal")}
        target="_blank"
        rel="noreferrer"
        aria-label="تواصل عبر واتساب"
      >
        <MessageCircle size={22} />
      </a>
      <nav className="mobile-bottom-nav">
        <a href="#home">
          <Sparkles size={18} />
          <span>الرئيسية</span>
        </a>
        <a href="#categories">
          <Menu size={18} />
          <span>التصنيفات</span>
        </a>
        <button onClick={() => setDrawer(true)}>
          <ShoppingBag size={18} />
          <span>السلة {count > 0 ? `(${count})` : ""}</span>
        </button>
        <a
          href={whatsappUrl("مرحباً، أريد الاستفسار عن منتجات Topchamal")}
          target="_blank"
          rel="noreferrer"
        >
          <MessageCircle size={18} />
          <span>واتساب</span>
        </a>
      </nav>

      {selected && (
        <div className="modal-backdrop" onClick={() => setSelected(null)}>
          <section
            className="product-modal"
            role="dialog"
            aria-modal="true"
            aria-label={selected.name}
            onClick={(e) => e.stopPropagation()}
          >
            <button className="modal-close" onClick={() => setSelected(null)} aria-label="إغلاق">
              <X size={19} />
            </button>
            <div className="modal-image">
              <img src={selected.image} alt={selected.name} />
            </div>
            <div className="modal-copy">
              <span className="product-category">{categoryName(selected.category)}</span>
              <h2>{selected.name}</h2>
              <p>{selected.description}</p>
              <Price product={selected} large />
              <div className="availability">
                <span /> متوفر للطلب عبر واتساب
              </div>
              <button
                className="primary-button full"
                onClick={() => {
                  add(selected);
                  setSelected(null);
                }}
              >
                أضف إلى السلة <ShoppingBag size={17} />
              </button>
              <a
                className="whatsapp-button"
                href={whatsappUrl(`مرحباً، أريد الاستفسار عن ${selected.name}`)}
                target="_blank"
                rel="noreferrer"
              >
                <MessageCircle size={17} /> اطلب عبر واتساب
              </a>
            </div>
          </section>
        </div>
      )}

      {drawer && (
        <div className="drawer-layer">
          <div
            className="drawer-backdrop"
            onClick={() => {
              setDrawer(false);
              setCheckout(false);
            }}
          />
          <aside
            className="drawer"
            role="dialog"
            aria-modal="true"
            aria-label={checkout ? "إتمام الطلب" : "السلة"}
          >
            <div className="drawer-head">
              <div>
                <span className="eyebrow plain">TOPCHAMAL</span>
                <h2>
                  {orderSent ? "تم تجهيز طلبك" : checkout ? "بيانات الطلب" : "سلة التسوق"}{" "}
                  {!checkout && !orderSent ? <small>({count})</small> : null}
                </h2>
              </div>
              <button
                className="icon-button"
                onClick={() => {
                  setDrawer(false);
                  setCheckout(false);
                  setOrderSent(false);
                }}
                aria-label="إغلاق"
              >
                <X size={19} />
              </button>
            </div>
            {orderSent ? (
              <div className="success-state">
                <div className="success-icon">
                  <MessageCircle size={30} />
                </div>
                <h3>رسالتك جاهزة</h3>
                <p>تم فتح واتساب برسالة طلبك. اختر جهة اتصال المتجر لإرسالها وتأكيد التفاصيل.</p>
                <button
                  className="primary-button full"
                  onClick={() => {
                    setDrawer(false);
                    setCheckout(false);
                    setOrderSent(false);
                  }}
                >
                  العودة للتسوق
                </button>
              </div>
            ) : checkout ? (
              <form id="checkout-form" className="checkout-form" onSubmit={order}>
                <p className="checkout-intro">الدفع عند الاستلام · سيُفتح واتساب لتأكيد الطلب.</p>
                <label>
                  الاسم الكامل
                  <input name="name" required placeholder="مثال: محمد العلوي" autoComplete="name" />
                </label>
                <label>
                  رقم الهاتف
                  <input
                    name="phone"
                    type="tel"
                    required
                    pattern="(0[567][0-9]{8}|\+?212[567][0-9]{8})"
                    title="أدخل رقم هاتف مغربي صالح"
                    placeholder="06xxxxxxxx"
                    autoComplete="tel"
                    dir="ltr"
                  />
                </label>
                <label>
                  المدينة والعنوان
                  <input
                    name="city"
                    required
                    placeholder="المدينة والعنوان"
                    autoComplete="street-address"
                  />
                </label>
                <button className="primary-button full" type="submit">
                  شارك الطلب عبر واتساب <MessageCircle size={17} />
                </button>
                <button className="back-button" type="button" onClick={() => setCheckout(false)}>
                  العودة إلى السلة
                </button>
              </form>
            ) : (
              <>
                {cart.length ? (
                  <div className="drawer-items">
                    {cart.map((line) => {
                      const product = products.find((item) => item.id === line.id);
                      return product ? (
                        <div className="cart-line" key={line.id}>
                          <img src={product.image} alt={product.name} />
                          <div className="cart-line-copy">
                            <strong>{product.name}</strong>
                            <Price product={product} />
                            <div className="qty">
                              <button onClick={() => qty(product.id, 1)} aria-label="زيادة">
                                <Plus size={14} />
                              </button>
                              <span className="num">{line.quantity}</span>
                              <button onClick={() => qty(product.id, -1)} aria-label="تقليل">
                                <Minus size={14} />
                              </button>
                            </div>
                          </div>
                        </div>
                      ) : null;
                    })}
                  </div>
                ) : (
                  <div className="empty-state">
                    <ShoppingBag size={30} />
                    <p>سلتك فارغة حالياً</p>
                    <button className="text-button" onClick={() => setDrawer(false)}>
                      تصفح المنتجات
                    </button>
                  </div>
                )}
                <div className="drawer-foot">
                  <div className="delivery-note">
                    <Truck size={17} />
                    <span>التوصيل يُؤكد مع المتجر حسب المدينة</span>
                  </div>
                  <div className="total">
                    <span>المجموع</span>
                    <strong className="num">{formatPrice(total)} د.م</strong>
                  </div>
                  <button
                    className="primary-button full"
                    disabled={!cart.length}
                    onClick={() => setCheckout(true)}
                  >
                    إتمام الطلب <ArrowLeft size={17} />
                  </button>
                </div>
              </>
            )}
          </aside>
        </div>
      )}
    </main>
  );
}
